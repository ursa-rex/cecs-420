JAMES BRYANT
5194642
access
arch_prctl
brk
close
execve
exit_group
fstat
mmap
mprotect
munmap
openat
read
write
