JAMES BRYANT
5194642

Preemptive Priority
--------------------
Avg Waiting Time: 37915
Avg Turn Around Time: 37926


First Come First Serve
-----------------------
Avg Waiting Time: 38263
Avg Turn Around Time: 38273
